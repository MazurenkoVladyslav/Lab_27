document.getElementById('create-product-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const category = document.getElementById('category').value;
    const price = document.getElementById('price').value;

    fetch('/product/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, category, price })
    }).then(response => {
        if (response.ok) {
            alert('Product created');
        }
    });
});

document.getElementById('update-product-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const id = document.getElementById('update-id').value;
    const price = document.getElementById('new-price').value;

    fetch(`/product/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ price })
    }).then(response => {
        if (response.ok) {
            alert('Product updated');
        }
    });
});

document.getElementById('delete-product-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const id = document.getElementById('delete-id').value;

    fetch(`/product/${id}`, {
        method: 'DELETE'
    }).then(response => {
        if (response.ok) {
            alert('Product deleted');
        }
    });
});

document.getElementById('fetch-products').addEventListener('click', function() {
    fetch('/product/list')
        .then(response => response.json())
        .then(products => {
            const productList = document.getElementById('product-list');
            productList.innerHTML = '';
            products.forEach(product => {
                const li = document.createElement('li');
                li.textContent = `ID: ${product._id}, Name: ${product.name}, Category: ${product.category}, Price: ${product.price}`;
                productList.appendChild(li);
            });
        });
});
