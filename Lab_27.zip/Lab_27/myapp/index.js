require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const Product = require('./models/Product');
const app = express();
const PORT = process.env.PORT || 3000;

console.log('MongoDB URI:', process.env.MONGODB_URI); 

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Could not connect to MongoDB', err));

app.use(express.json());
app.use(express.static('public'));

app.get('/product/list', async (req, res) => {
    const products = await Product.find();
    res.json(products);
});

app.post('/product/create', async (req, res) => {
    const { name, category, price } = req.body;
    const product = new Product({ name, category, price });
    await product.save();
    res.status(201).send('Product created');
});


app.put('/product/:id', async (req, res) => {
    const { id } = req.params;
    const { price } = req.body;
    const product = await Product.findByIdAndUpdate(id, { price }, { new: true });
    if (product) {
        res.send('Product updated');
    } else {
        res.status(404).send('Product not found');
    }
});


app.delete('/product/:id', async (req, res) => {
    const { id } = req.params;
    const product = await Product.findByIdAndDelete(id);
    if (product) {
        res.send('Product deleted');
    } else {
        res.status(404).send('Product not found');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
